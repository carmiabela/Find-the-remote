//  /*#-localizable-zone(SharedCodeCopyright1)*/Copyright/*#-end-localizable-zone*/ © 2016-2019 Apple Inc. /*#-localizable-zone(SharedCodeCopyright2)*/All rights reserved./*#-end-localizable-zone*/

//#-localizable-zone(Shapes01)
// Shared Code
// Code written in this file is available on all pages in this Playground Book.
//#-end-localizable-zone
